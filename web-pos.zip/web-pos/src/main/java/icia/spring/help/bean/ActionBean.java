package icia.spring.help.bean;


import lombok.Data;

@Data
public class ActionBean {
	private boolean isRedirect;
	private String page;
	
	
}
