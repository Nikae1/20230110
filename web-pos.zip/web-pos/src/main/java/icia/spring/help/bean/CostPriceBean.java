package icia.spring.help.bean;

import lombok.Data;

@Data
public class CostPriceBean {
	private String priceDday;
	private int	cost;
	private int price;
	private String priceCategoryCode;
	private String priceComment;
	
	
}
