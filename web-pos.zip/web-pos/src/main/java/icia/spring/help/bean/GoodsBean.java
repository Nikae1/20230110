package icia.spring.help.bean;

import lombok.Data;

@Data
public class GoodsBean {

	private String goodsCode;
	private String goodsName;
	private String goodsState;
	private String goodslevCode;
	private String goodsImage;
	private String goodsColor;
	
}
