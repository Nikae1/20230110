package icia.spring.help.bean;

public class ImagesBean {
	private String imageCode;
	private String imageDisplayName;
	private String imageLocation;
	
	
	public String getImageCode() {
		return imageCode;
	}
	public void setImageCode(String imageCode) {
		this.imageCode = imageCode;
	}
	public String getImageDisplayName() {
		return imageDisplayName;
	}
	public void setImageDisplayName(String imageDisplayName) {
		this.imageDisplayName = imageDisplayName;
	}
	public String getImageLocation() {
		return imageLocation;
	}
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}
}
