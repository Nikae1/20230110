package icia.spring.help.services.auth;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import icia.spring.help.bean.GroupBean;
import lombok.extern.slf4j.Slf4j;

/**/
@Service
@Slf4j
public class Authentication {
	@Autowired
	private SqlSessionTemplate session;
	public Authentication() {}
	
	public void backController(int serviceCode, Model model) {
		switch(serviceCode) {
		case 11:
			this.groupNameDuplicateCheckCtl(model);
		}
	}

	public void backController(int serviceCode, ModelAndView mav) {
		switch(serviceCode) {
		case 1:
			break;
		}
	}
	
	/* 중복체크 검사 */
	private void groupNameDuplicateCheckCtl(Model model) {
		GroupBean group = ((GroupBean)model.getAttribute("group"));
	//	log.info("{}", ((GroupBean)model.getAttribute("group")).getGroupName());
	
		
		log.info("{}", (int)this.session.selectOne("isGroupName", group));
	
		/* Temp에 중복검사 // 동시에 같은 groupName을 사용하는 경우를 대비 */
	if(!this.convertToBoolean(this.session.selectOne("isGroupName", group))) {
		
		
		if(this.convertToBoolean(this.session.insert("insTemp", group))) {
		}else {group.setMessage("NetWork Error: 네트워크가 불안정합니다. 잠시 후 다시 이용해주세요.");}
	
	}
	else {group.setMessage("GroupName Error: 이미 사용중인 그룹명입니다. 다른 이름을 사용해주세요.");}
	
	}
	
	
	
	private boolean convertToBoolean(int value) {
		return (value >= 1)? true : false;
	}
	
	
}
